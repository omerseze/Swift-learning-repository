import UIKit


//set


//unordered collection, unique elements

var mySet:Set = [1,2,3,4,5,6,1,2,3,7,8]
var myStringset : Set = ["a","b","c","a"]
mySet

myStringset
