import UIKit


//options


var myName :String = "james"


myName.uppercased()

// optionasl : ? vs !

var myAge = "5"

var myInteger = Int(myAge)! * 5
