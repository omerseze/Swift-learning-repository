import UIKit

// ıf & else

// and &&
// or veya ||
var myAge = 32

if myAge < 30 {
    print("30 - ")
} else if  myAge > 30 && myAge < 40 {
    print("otuz yaşlarında")
}else {
    print("40  + ")
}
