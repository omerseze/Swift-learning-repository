import UIKit

var greeting = "Hello, playground"

var mynumber = 5 * 4
print(mynumber)


