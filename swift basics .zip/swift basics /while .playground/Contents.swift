import UIKit

//while



var number = 0
//while loop

while number <= 10 {
    print(number)
    number += 1
}


var chacracterAlive = true
while chacracterAlive  == true {
    print("doğru")
    chacracterAlive = false
    

}


//for loop

var myFruit  = ["banana","apple","orange","tomato"]

myFruit[2]


for fruite in myFruit{
    print(fruite)
}

var myNumbers  = [10,20,30,40,50,60]

for num in myNumbers{
    print(num/5)
}

for number in 1 ... 5 {
    print(number * 10)
}

