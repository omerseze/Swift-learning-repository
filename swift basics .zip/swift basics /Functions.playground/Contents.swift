import UIKit

// function

func myFunction (){
    print("my function")
}

myFunction()

// ınput & outbot & return

func sumfunction(x: Int,y: Int) -> Int {
    return x + y
    
}
let sumfunctionVariable = sumfunction(x: 10, y: 20)
print(sumfunctionVariable)


func logicFunction(a : Int, b: Int) -> Bool {
    if a > b {
        return true
    }else {
        return false
    }
}

logicFunction(a: 5, b: 3)
