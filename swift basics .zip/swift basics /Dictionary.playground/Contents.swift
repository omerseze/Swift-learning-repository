import UIKit

// Dictionary

// key-value pairing

var myFavoritedirecors = ["görevimiz tehlike":"tom cruise","fast and furios":"vin diesel","the dark night":"christopher nolan"]

myFavoritedirecors["görevimiz tehlike"]
myFavoritedirecors["fast and furios"]

//change
myFavoritedirecors["fast and furios"] = "paul walker"


var myDictionary = ["Run":200,"swim":300,"football":150,"basketball":350,"walking":100]
myDictionary["walking"]
