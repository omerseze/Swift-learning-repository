import UIKit

// variables and constants


//string
var userName = "vladamir"
userName.append("o")
userName.lowercased()
userName.uppercased()
print(userName)
var userSurname = "putin"

userName = "thomas"
print(userName)


//constannt

let userAge = 50


//integer & float & double

//integer
let uuserAge = 50

//double
let pi = 3.14

let userAgeD = 50.0
let myNumber = 4.0

userAgeD / myNumber

//boolean

var myBoolean = false

var myBooolean = true




// ---- level2------


let  myString : String = "50"
let anotherNumber : Int = 10

let  stringNumber : String = String(20)

//define

let myVariable :String

//initialization

myVariable = "test"
myVariable.uppercased()




