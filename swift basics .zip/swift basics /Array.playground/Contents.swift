import UIKit

// Array

var myFavoriteMovies = ["bir zamanlar anadoluda","oppenheimer","new yorkta beş minare","test1",5,true] as [Any]


// as -> casting
// any -> any object



//index
myFavoriteMovies[0]
myFavoriteMovies[1]
myFavoriteMovies[2]
myFavoriteMovies[3]


var stringArray = ["test1","test2","test3"]

stringArray[0].uppercased()
stringArray.count

stringArray[stringArray.count-1]
stringArray.last

stringArray.sort()

